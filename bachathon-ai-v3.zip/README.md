# Bachathon AI v3

A full-stack prototype for an online-jobs marketplace.

## New in v3
- Admin moderation dashboard API for jobs and users
- Employer job-review workflow: pending → approved/rejected
- Employer verification flag
- In-app notifications for applications, status changes and job reviews
- CV upload endpoint (PDF/Word, 5 MB limit)
- Safer public job listing: only approved jobs are searchable
- Admin bootstrap via environment variables

## Run locally
```bash
npm install
ADMIN_EMAIL=admin@example.com ADMIN_PASSWORD='change-me-strong-password' SESSION_SECRET='use-a-long-random-secret' npm start
```
Then open `http://localhost:3000`.

## Important production notes
This is a strong prototype foundation, not a final security audit. Before public launch, configure a real persistent session store, HTTPS, secure secrets, email delivery for verification/password reset, malware scanning for uploads, backups, logging/monitoring, rate limiting, CSRF strategy, and a production database/hosting setup.
