const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'bachathon.db'));
db.pragma('journal_mode = WAL');

const uploadDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /pdf|msword|officedocument/.test(file.mimetype))
});

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'seeker', skills TEXT DEFAULT '', bio TEXT DEFAULT '',
 verified INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS jobs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, company TEXT NOT NULL, category TEXT NOT NULL,
 location TEXT DEFAULT 'Remote', type TEXT DEFAULT 'Part-time', description TEXT NOT NULL, skills TEXT DEFAULT '',
 verified INTEGER DEFAULT 0, status TEXT DEFAULT 'pending', employer_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(employer_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL, user_id INTEGER NOT NULL, cover_note TEXT DEFAULT '',
 status TEXT DEFAULT 'Applied', created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(job_id,user_id),
 FOREIGN KEY(job_id) REFERENCES jobs(id), FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS documents (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL, original_name TEXT NOT NULL,
 stored_name TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL,
 read INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

// Optional first-admin bootstrap. Set ADMIN_EMAIL and ADMIN_PASSWORD in the deployment environment.
if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
  const email = process.env.ADMIN_EMAIL.toLowerCase();
  const exists = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (!exists) {
    db.prepare('INSERT INTO users(name,email,password_hash,role,verified) VALUES(?,?,?,?,1)')
      .run('Bachathon AI Admin', email, bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12), 'admin');
    console.log('Admin account created from environment variables.');
  }
}

const count = db.prepare('SELECT COUNT(*) c FROM jobs').get().c;
if (!count) {
 const seed = db.prepare(`INSERT INTO jobs(title,company,category,location,type,description,skills,verified,status) VALUES(?,?,?,?,?,?,?,?,?)`);
 [
  ['Online Data Annotator','Bachathon AI Projects','Data Annotation','Worldwide','Part-time','Label and review text, image, and audio data for AI systems.','Attention to detail, English, data labeling',1,'approved'],
  ['Content Moderator','Global Tech Partner','Content Moderation','Multiple regions','Full-time','Review digital content against clear community and safety guidelines.','English, judgment, communication',1,'approved'],
  ['Customer Support Specialist','E-commerce Company','Customer Experience','Worldwide','Part-time','Support customers through chat and email while documenting resolutions.','Customer service, writing, computer skills',1,'approved'],
  ['Search Quality Evaluator','AI Research Partner','Artificial Intelligence','Multiple regions','Part-time','Evaluate search results and provide structured quality feedback.','Research, web skills, critical thinking',1,'approved'],
  ['Virtual Assistant','Digital Agency','Administrative','Worldwide','Part-time','Assist with scheduling, research, inbox management and routine admin tasks.','Organization, communication, spreadsheets',1,'approved']
 ].forEach(j=>seed.run(...j));
}

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret:process.env.SESSION_SECRET || 'change-this-in-production', resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:1000*60*60*24*7}
}));
app.use(express.static(path.join(__dirname,'public')));

function auth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:'Please log in first.'}); next(); }
function user(req){ return db.prepare('SELECT id,name,email,role,skills,bio,verified,created_at FROM users WHERE id=?').get(req.session.userId); }
function role(name){ return (req,res,next)=>{ const u=user(req); if(!u || u.role!==name) return res.status(403).json({error:`${name} account required.`}); next(); }; }
function notify(userId,title,message){ db.prepare('INSERT INTO notifications(user_id,title,message) VALUES(?,?,?)').run(userId,title,message); }

app.get('/api/me',(req,res)=>res.json({user:req.session.userId?user(req):null}));
app.post('/api/register',(req,res)=>{
 const {name,email,password,role:accountRole='seeker'}=req.body;
 if(!name||!email||!password) return res.status(400).json({error:'Name, email and password are required.'});
 if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters.'});
 if(!['seeker','employer'].includes(accountRole)) return res.status(400).json({error:'Invalid account type.'});
 try { const hash=bcrypt.hashSync(password,12); const info=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(name,email.toLowerCase(),hash,accountRole); req.session.userId=info.lastInsertRowid; res.status(201).json({user:user(req)}); }
 catch(e){ res.status(409).json({error:'An account with that email already exists.'}); }
});
app.post('/api/login',(req,res)=>{ const {email,password}=req.body; const u=db.prepare('SELECT * FROM users WHERE email=?').get((email||'').toLowerCase()); if(!u||!bcrypt.compareSync(password||'',u.password_hash)) return res.status(401).json({error:'Invalid email or password.'}); req.session.userId=u.id; res.json({user:user(req)}); });
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.put('/api/profile',auth,(req,res)=>{ const {name,skills,bio}=req.body; db.prepare('UPDATE users SET name=?,skills=?,bio=? WHERE id=?').run(name||'',skills||'',bio||'',req.session.userId); res.json({user:user(req)}); });

app.get('/api/notifications',auth,(req,res)=>res.json({notifications:db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.session.userId)}));
app.patch('/api/notifications/:id/read',auth,(req,res)=>{db.prepare('UPDATE notifications SET read=1 WHERE id=? AND user_id=?').run(req.params.id,req.session.userId);res.json({ok:true})});

app.post('/api/profile/cv',auth,upload.single('cv'),(req,res)=>{
 if(!req.file) return res.status(400).json({error:'Please upload a PDF or Word document up to 5MB.'});
 const existing=db.prepare('SELECT stored_name FROM documents WHERE user_id=? AND kind=?').get(req.session.userId,'cv');
 if(existing) { try { fs.unlinkSync(path.join(uploadDir,existing.stored_name)); } catch {} db.prepare('DELETE FROM documents WHERE user_id=? AND kind=?').run(req.session.userId,'cv'); }
 db.prepare('INSERT INTO documents(user_id,kind,original_name,stored_name) VALUES(?,?,?,?)').run(req.session.userId,'cv',req.file.originalname,req.file.filename);
 res.status(201).json({message:'CV uploaded successfully.',filename:req.file.originalname});
});

app.get('/api/jobs',(req,res)=>{
 const q=(req.query.q||'').trim(); const category=(req.query.category||'').trim(); let sql='SELECT j.*, u.name employer_name FROM jobs j LEFT JOIN users u ON u.id=j.employer_id WHERE j.status=\'approved\''; const params=[];
 if(q){sql+=' AND (j.title LIKE ? OR j.company LIKE ? OR j.description LIKE ? OR j.skills LIKE ?)';const x=`%${q}%`;params.push(x,x,x,x)}
 if(category){sql+=' AND j.category=?';params.push(category)} sql+=' ORDER BY j.created_at DESC'; res.json({jobs:db.prepare(sql).all(...params)});
});
app.get('/api/jobs/:id',(req,res)=>{const job=db.prepare('SELECT * FROM jobs WHERE id=? AND status=\'approved\'').get(req.params.id);if(!job)return res.status(404).json({error:'Job not found.'});res.json({job})});
app.post('/api/jobs',auth,role('employer'),(req,res)=>{
 const u=user(req); const {title,company,category,location,type,description,skills}=req.body;
 if(!title||!company||!category||!description)return res.status(400).json({error:'Title, company, category and description are required.'});
 const info=db.prepare('INSERT INTO jobs(title,company,category,location,type,description,skills,employer_id,status) VALUES(?,?,?,?,?,?,?,?,?)').run(title,company,category,location||'Remote',type||'Part-time',description,skills||'',u.id,'pending');
 notify(u.id,'Job submitted','Your job posting is awaiting Bachathon AI review.'); res.status(201).json({job:db.prepare('SELECT * FROM jobs WHERE id=?').get(info.lastInsertRowid)});
});
app.post('/api/jobs/:id/apply',auth,(req,res)=>{const u=user(req);if(u.role!=='seeker')return res.status(403).json({error:'Only job seeker accounts can apply.'});const job=db.prepare('SELECT id,title,employer_id FROM jobs WHERE id=? AND status=\'approved\'').get(req.params.id);if(!job)return res.status(404).json({error:'Job not found.'});try{db.prepare('INSERT INTO applications(job_id,user_id,cover_note) VALUES(?,?,?)').run(job.id,u.id,req.body.cover_note||'');if(job.employer_id)notify(job.employer_id,'New application',`${u.name} applied for ${job.title}.`);notify(u.id,'Application submitted',`Your application for ${job.title} was submitted.`);res.status(201).json({message:'Application submitted.'})}catch(e){res.status(409).json({error:'You have already applied for this job.'})}});
app.get('/api/applications',auth,role('seeker'),(req,res)=>res.json({applications:db.prepare(`SELECT a.*,j.title,j.company,j.category FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.created_at DESC`).all(req.session.userId)}));
app.get('/api/employer/applications',auth,role('employer'),(req,res)=>{const u=user(req);res.json({applications:db.prepare(`SELECT a.*,j.title,j.company,u.name candidate_name,u.email candidate_email FROM applications a JOIN jobs j ON j.id=a.job_id JOIN users u ON u.id=a.user_id WHERE j.employer_id=? ORDER BY a.created_at DESC`).all(u.id)})});
app.patch('/api/applications/:id',auth,role('employer'),(req,res)=>{const u=user(req);const row=db.prepare(`SELECT a.id,a.user_id,j.title FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.id=? AND j.employer_id=?`).get(req.params.id,u.id);if(!row)return res.status(404).json({error:'Application not found.'});const allowed=['Applied','Under Review','Accepted','Rejected'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status.'});db.prepare('UPDATE applications SET status=? WHERE id=?').run(req.body.status,req.params.id);notify(row.user_id,'Application status updated',`Your application for ${row.title} is now ${req.body.status}.`);res.json({ok:true})});

// Admin moderation API
app.get('/api/admin/overview',auth,role('admin'),(req,res)=>res.json({
 users:db.prepare('SELECT COUNT(*) c FROM users').get().c,
 employers:db.prepare("SELECT COUNT(*) c FROM users WHERE role='employer'").get().c,
 pendingJobs:db.prepare("SELECT COUNT(*) c FROM jobs WHERE status='pending'").get().c,
 applications:db.prepare('SELECT COUNT(*) c FROM applications').get().c
}));
app.get('/api/admin/jobs',auth,role('admin'),(req,res)=>res.json({jobs:db.prepare(`SELECT j.*,u.name employer_name,u.email employer_email FROM jobs j LEFT JOIN users u ON u.id=j.employer_id ORDER BY j.created_at DESC`).all()}));
app.patch('/api/admin/jobs/:id',auth,role('admin'),(req,res)=>{const allowed=['pending','approved','rejected'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid job status.'});const j=db.prepare('SELECT * FROM jobs WHERE id=?').get(req.params.id);if(!j)return res.status(404).json({error:'Job not found.'});db.prepare('UPDATE jobs SET status=?,verified=? WHERE id=?').run(req.body.status,req.body.status==='approved'?1:0,req.params.id);if(j.employer_id)notify(j.employer_id,'Job review completed',`Your job “${j.title}” was ${req.body.status}.`);res.json({ok:true})});
app.get('/api/admin/users',auth,role('admin'),(req,res)=>res.json({users:db.prepare('SELECT id,name,email,role,verified,created_at FROM users ORDER BY created_at DESC').all()}));
app.patch('/api/admin/users/:id/verify',auth,role('admin'),(req,res)=>{const target=db.prepare('SELECT id,role FROM users WHERE id=?').get(req.params.id);if(!target)return res.status(404).json({error:'User not found.'});db.prepare('UPDATE users SET verified=? WHERE id=?').run(req.body.verified?1:0,target.id);notify(target.id,'Account verification updated',req.body.verified?'Your employer account has been verified.':'Your verification status was changed.');res.json({ok:true})});

app.use((req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Bachathon AI running at http://localhost:${PORT}`));
