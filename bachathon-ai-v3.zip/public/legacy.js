const jobs=[
['Online Data Annotator','Bachathon AI Projects','Data Annotation','Worldwide','Part-time'],
['Content Moderator','Global Tech Partner','Content Moderation','Multiple regions','Full-time / Part-time'],
['Customer Support Specialist','E-commerce Company','Customer Experience','Worldwide','Part-time'],
['Search Quality Evaluator','AI Research Partner','Artificial Intelligence','Multiple regions','Part-time'],
['Virtual Assistant','Digital Agency','Administrative','Worldwide','Part-time'],
['AI Response Evaluator','AI Research Partner','Artificial Intelligence','Remote','Flexible'],
['Audio Transcription Specialist','Digital Solutions Co.','AI Community','Worldwide','Contract'],
['Image Annotation Specialist','Bachathon AI Projects','Data Annotation','Remote','Part-time']
];
function render(list){const grid=document.getElementById('jobGrid');grid.innerHTML=list.length?list.map(j=>`<article class="job"><span class="tag">Remote</span><h3>${j[0]}</h3><p>${j[1]}</p><div class="meta">⌖ ${j[3]}<br>◷ ${j[4]}<br>✦ ${j[2]}</div><a class="apply" href="#signup" onclick="alert('Application flow coming next — this demo button is ready to connect to your application system.')">Apply Now →</a></article>`).join(''):'<div class="empty">No matching opportunities found. Try another keyword or category.</div>'}
function filterJobs(){const q=document.getElementById('search').value.toLowerCase();const c=document.getElementById('category').value.toLowerCase();render(jobs.filter(j=>(!q||j.join(' ').toLowerCase().includes(q))&&(!c||j[2].toLowerCase()===c)));document.getElementById('jobs').scrollIntoView({behavior:'smooth'})}
render(jobs);
</script>
